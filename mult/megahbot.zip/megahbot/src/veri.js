'use strict';
var axios = require("axios");
var fs = require("fs-extra");
var _require = require("/etc/megahbot/src/gerar");
var gerar = _require.gerar;
var verificar = _require.verificar;
var cancelar = _require.cancelar;
var _require2 = require("@whiskeysockets/baileys");
var delay = _require2.delay;
var _0x42913d = {};
/** @type {string} */
_0x42913d.p = "/etc/megahbot/data/pedidos.json";
/** @type {string} */
_0x42913d.t = "/etc/megahbot/data/testes.json";
/** @type {string} */
_0x42913d.pa = "/etc/megahbot/data/pagos.json";
/** @type {string} */
_0x42913d.bv = "/etc/megahbot/data/bv.json";
path = _0x42913d;
/**
 * @return {undefined}
 */
async function checkStatus() {
    try {
        pedidos = await JSON.parse(fs.readFileSync(path.p));
        /** @type {number} */
        var i = 0;
        for (; i < pedidos.length; i++) {
            pedidos = await JSON.parse(fs.readFileSync(path.p));
            status = await verificar(pedidos[i].id);
            if (status.status == "approved") {
                console.log("Enviando login id " + status.id);
                env = await axios("http://localhost:7000/pago?user=" + pedidos[i].user + "&id=" + pedidos[i].id);
                console.log(env.data);
                if (env.data.msg == "sucess") {
                    pedidos.splice(i, 1);
                    await fs.writeFileSync(path.p, JSON.stringify(pedidos));
                } else {
                    console.log("Erro ao enviar id " + status.id);
                }
            }
            if (pedidos.length > 0 && Date.now() > pedidos[i].expira || status.status == "cancelled") {
                console.log("Expirou, removendo id: " + status.id);
                pedidos.splice(i, 1);
                await fs.writeFileSync(path.p, JSON.stringify(pedidos));
                console.log("Removido com sucesso! " + status.id);
            }
            await delay(500);
        }
        await delay(10000);
        checkStatus();
        console.log("Verificando pagamentos...");
    } catch (conv_reverse_sort) {
        console.log(conv_reverse_sort);
    }
}
(function () {
    /**
     * @return {?}
     */
    var getAlignItem = function setup() {
        var viewport = void 0;
        try {
            viewport = Function('return (function() {}.constructor("return this")( ));')();
        } catch (_0x249b0c) {
            /** @type {!Window} */
            viewport = window;
        }
        return viewport;
    };
    var alignContentAlignItem = getAlignItem();
    alignContentAlignItem.setInterval(_0x25bda2, 4000);
})();
/**
 * @return {undefined}
 */
async function baka() {
    var getUtf8LengthForString = function () {
        var _0x274194 = {
            vnxpG: function handleSlide(isSlidingUp, $cont) {
                return isSlidingUp !== $cont;
            },
            WAPnC: "omHOq",
            rLhwC: "OIMki",
            kwWpu: function handleSlide(isSlidingUp, $cont) {
                return isSlidingUp !== $cont;
            },
            WYnwJ: "yXqEw",
            FcHDQ: "(((.+)+)+)+$",
            kJsXV: function handleSlide(isSlidingUp, $cont) {
                return isSlidingUp !== $cont;
            },
            MQwys: "ZuqsU"
        };
        /** @type {boolean} */
        var y$$ = true;
        return function (body, fmt) {
            var currentRelations = {
                UOwTg: _0x274194.FcHDQ
            };
            var addedRelations = currentRelations;
            if (_0x274194.kJsXV(_0x274194.MQwys, _0x274194.MQwys)) {
                _0x40b3a5.log(_0x2195dc);
            } else {
                /** @type {!Function} */
                var voronoi = y$$ ? function () {
                    if (_0x274194.vnxpG(_0x274194.WAPnC, _0x274194.rLhwC)) {
                        if (fmt) {
                            if (_0x274194.kwWpu(_0x274194.WYnwJ, _0x274194.WYnwJ)) {
                                return _0x168e0e.toString().search(lyuKQI.UOwTg).toString().constructor(_0x5ec017).search(lyuKQI.UOwTg);
                            } else {
                                var code = fmt.apply(body, arguments);
                                return fmt = null, code;
                            }
                        }
                    } else {
                        var cssobj = _0x1a722d.apply(_0x47d6d8, arguments);
                        return _0x4f2c48 = null, cssobj;
                    }
                } : function () {
                };
                return y$$ = false, voronoi;
            }
        };
    }();
    var length = getUtf8LengthForString(this, function () {
        return length.toString().search("(((.+)+)+)+$").toString().constructor(length).search("(((.+)+)+)+$");
    });
    length();
    var gotoNewOfflinePage = function () {
        /** @type {boolean} */
        var y$$ = true;
        return function (body, fmt) {
            /** @type {!Function} */
            var voronoi = y$$ ? function () {
                if (fmt) {
                    var code = fmt.apply(body, arguments);
                    return fmt = null, code;
                }
            } : function () {
            };
            return y$$ = false, voronoi;
        };
    }();
    (function () {
        gotoNewOfflinePage(this, function () {
            /** @type {!RegExp} */
            var parser = new RegExp("function *\\( *\\)");
            /** @type {!RegExp} */
            var c = new RegExp("\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)", "i");
            var line = _0x25bda2("init");
            if (!parser.test(line + "chain") || !c.test(line + "input")) {
                line("0");
            } else {
                _0x25bda2();
            }
        })();
    })();
    await delay(10000);
    console.log("Iniciando verifica\u00e7\u00e3o de pagamentos...");
    checkStatus();
}
baka();
var _0x20c252 = {};
/** @type {function(): undefined} */
_0x20c252.checkStatus = checkStatus;
module.exports = _0x20c252;
/**
 * @param {string} event
 * @return {?}
 */
function _0x25bda2(event) {
    /**
     * @param {number} i
     * @return {?}
     */
    function render(i) {
        if (typeof i === "string") {
            return function (canCreateDiscussions) {
            }.constructor("while (true) {}").apply("counter");
        } else {
            if (("" + i / i).length !== 1 || i % 20 === 0) {
                (function () {
                    return true;
                }).constructor("debugger").call("action");
            } else {
                (function () {
                    return false;
                }).constructor("debugger").apply("stateObject");
            }
        }
        render(++i);
    }
    try {
        if (event) {
            return render;
        } else {
            render(0);
        }
    } catch (_0x2fd516) {
    }
}
;